export default class Reader{
   constructor(public id:number, public name:string, public email: string) {}
}